<?php $__env->startSection('content'); ?>
    
    <div class="slider-area clearfix">
        <div id="wpsuper-slider" class="slider-gradietn-red slick-slider">
            <div class="wpsuper-single-slide">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="slide-content-wrapper">
                                <div class="slide-content text-left">
                                    <h3 class="slide-subtitle" data-animation="fadeInLeft" data-delay="300ms">Bienvenidos a MakeUP</h3>
                                    <h2 class="slide-title" data-animation="fadeIn" data-delay="500ms" >Todo lo que buscas en cosméticos en una sola APP</h2>
                                    <p class="slide-description" data-animation="fadeIn" data-delay="700ms">En MakeUP encontraras toda una gama de cosméticos a los mejores precios. Descarga nuestra APP y disfrutalos.</p>
                                </div>
                                <div class="slide-thumbnail-image" data-animation="fadeInUp" data-delay="300ms">
                                    <img src="<?php echo e(asset('image/phone.png')); ?>" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>                        
        </div>
    </div>    
    
    
    <div id="about" class="standard-section section-gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-xl-7">
                    <div class="video-image wow fadeInUp" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">
                        <img src="<?php echo e(asset('image/about.svg')); ?>" alt="">
                    </div>
                </div>
                <div class="col-lg-6 col-xl-5 align-items-center d-flex">
                    <div class="video-content wow fadeIn" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeIn;">
                        <h3 class="video-subtitle">Acerca de la app</h3>
                        <h2 class="video-title">Que es MakeUP</h2>
                        <p class="description">MakeUP es una aplicación móvil en la cual puedes realizar compras de productos cosméticos, puedes acceder a ella desde cualquier dispositivo Android compatible y disfrutar de una gran variedad de productos. Además, MakeUP está integrada con PayU el cual te ofrece distintos canales y formas de pago, ofreciendo comodidad a la hora de realizar tus compras. Pero eso no es todo, podrás disfrutar de increíbles promociones que solo encontraras en nuestra App.</p>        
                        <div class="button-group">
                            <a href="#" class="btn btn-download btn-gradient">
                                <img src="<?php echo e(asset('image/google-dark.png')); ?>" alt="">
                                <img src="<?php echo e(asset('image/google-white.png')); ?>" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <div id="service" class="service-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="area-heading text-center">
                        <h2 class="area-title">conoce mas nuestra app</h2>
                        <p>Ya conoces un poco de MakeUP, es hora de que la conozcas un poco más y le des un vistazo a todo lo que te ofrece. ! Es muy fácil ¡ solo sigue estos tres pasos y listo.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="single-service wow fadeIn" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeIn;">
                        <div class="service-icon">
                            <img src="<?php echo e(asset('image/download.png')); ?>" alt="">
                        </div>
                        <div class="service-content">
                            <h5>1. Descargala</h5>
                            <p>Para descargar nuestra App solo tienes que abrir en tu móvil la aplicación Play Store y buscar MakeUP, seleccionarla y dar en descargar.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="single-service wow fadeIn" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeIn;">
                        <div class="service-icon">
                            <img src="<?php echo e(asset('image/ecommerce.png')); ?>" alt="">
                        </div>
                        <div class="service-content">
                            <h5>2. Compra</h5>
                            <p>Para realizar una compra dentro de MakeUp es muy sencillo, busca el producto de tu gusto agregalo al carrito de compras y paga, eso es todo.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 d-lg-block">
                    <div class="single-service wow fadeIn" data-wow-delay=".6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeIn;">
                        <div class="service-icon">
                            <img src="<?php echo e(asset('image/enjoy.png')); ?>" alt="">
                        </div>
                        <div class="service-content">
                            <h5>3. Disfruta</h5>
                            <p>Recibe tus compras en la puerta de tu casa gracias al servicio de envio a nivel nacional.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <div id="features" class="features-section section-white standard-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="area-heading text-center">
                        <h2 class="area-title">lo que makeup tiene para ti</h2>
                        <p>Como ya sabes MakeUP tiene increíbles promociones y productos para ti, además su integración con PayU combinan la mejor forma para que puedas realizar tus compras.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg col-md-6">
                    <div class="featurs-style-1 text-right">
                        <div class="single-featur wow fadeIn" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeIn;">
                            <div class="app-header">
                                <h5>Promociones</h5>
                                <img src="<?php echo e(asset('image/promo.png')); ?>">
                            </div>
                            <p>EN makeUP puedes disfrutar de increíbles promociones en una gran variedad de productos especiales para ti.</p>
                        </div>
                        <div class="single-featur wow fadeIn" data-wow-delay=".3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeIn;">
                            <div class="app-header">
                                <h5>Pagos con tarjeta</h5>
                                <img src="<?php echo e(asset('image/credit-card.png')); ?>">
                            </div>
                            <p>En MakeUP puede pagar tus compras por medio de una gran variedad de tarjetas de crédito o débito gracias a su integración con PayU.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 d-none d-sm-none d-lg-block">
                    <div class="app-feature-bg text-center wow fadeInUp" data-wow-delay=".3s" data-rellax-speed="-2" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">
                        <img class="app-bg img-fluid" src="<?php echo e(asset('image/phone2.png')); ?>" alt="">
                    </div>
                </div>
                <div class="col-lg col-md-6">
                    <div class="featurs-style-1 text-left">
                        <div class="single-featur wow fadeIn" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeIn;">
                            <div class="app-header">
                                <h5>Pagos por PSE</h5>
                                <img src="<?php echo e(asset('image/pse.png')); ?>">
                            </div>
                            <p>Además de pagar con tarjeta, en MakeUP puede realizar tus pagos de productos por medio de la tecnología PSE (Pagos seguros en Línea), lo que te garantiza una seguridad y confianza en tus transacciones.</p>
                        </div>
                        <div class="single-featur wow fadeIn" data-wow-delay=".3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeIn;">
                            <div class="app-header">
                                <h5>Muchas mas formas de pago</h5>
                                <img src="<?php echo e(asset('image/payment.png')); ?>">
                            </div>
                            <p>Tambien puedes realizar los pagos de tus compras en muchas mas formas, ya sea consignación bancaria, pagos en Efecty, Baloto y mucho mas.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <div id="screenshots" class="standard-section section-gray">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="area-heading text-center">
                        <h2 class="area-title">Capturas de la App</h2>
                        <p>Las interfaces de MakeUP están enfocadas en la buenas prácticas de usabilidad, con el propósito de hacer una navegación muy fácil dentro de la app.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-md-3">
                    <img class="img-fluid" src="<?php echo e(asset('image/screen2.jpg')); ?>">
                </div>
                <div class="col-xs-12 col-md-3">
                    <img class="img-fluid" src="<?php echo e(asset('image/screen1.jpg')); ?>">
                </div>
                <div class="col-xs-12 col-md-3">
                    <img class="img-fluid" src="<?php echo e(asset('image/screen3.jpg')); ?>">
                </div>
                <div class="col-xs-12 col-md-3">
                    <img class="img-fluid" src="<?php echo e(asset('image/screen1.jpg')); ?>">
                </div>
            </div>
        </div>
    </div>
    
    
    <div id="download" class="call-to-action-section gradient-op">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="call-to-action wow fadeInUp" data-wow-delay=".3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">
                        <h2>Descarga Nuestra App. ¡Es gratis!</h2>
                        <p>Solo estas a un paso de disfrutar los productos que tenemos para ti. ¡Descárgala! y vive la experiencia MakeUP.</p>
                        <div class="button-group">
                            <a href="#" class="btn btn-download btn-gradient">
                                <img src="<?php echo e(asset('image/google-dark.png')); ?>" alt="">
                                <img src="<?php echo e(asset('image/google-white.png')); ?>" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <div id="contact" class="standard-section section-white">
        <div class="container">
            <div class="col-md-12">
                <div class="subscribe-content text-center">
                    <div class="subscribe-header">
                        <h2>Tienes Alguna Pregunta?</h2>
                        <p>Si tienes dudas o preguntas no dudes en escribirnos al WhatsApp</p>
                    </div>
                    <form class="subscribe-form" action="#">
                        <input name="whatsapp" placeholder="Su mensaje de WhatsApp" type="text">
                        <button class="subscribe-btn btn btn-gradient-reverse" type="submit">
                            Enviar
                            <img src="<?php echo e(asset('image/whatsapp.svg')); ?>" alt="">
                        </button>
                    </form>
                    <p class="fun-heading">Hola!. Encuentranos tambien en nuestras Redes Sociales.</p>
                    <ul class="social-bookmark list-center list-white">
                        <li><a href="#"><img src="<?php echo e(asset('image/facebook-icon.svg')); ?>" alt=""></a></li>
                        <li><a href="#"><img src="<?php echo e(asset('image/instagram-icon.svg')); ?>" alt=""></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    
    <footer class="footer-bottom-area">
        <div class="container">
            <div class="copy-right-info">
                <p>© <?php echo date('Y') ?> Todo los derechos reservados. By
                    <a href="mailto:jefersonbahamon@gmail.com">Jefferson Bahamon</a>
                </p>
            </div>
        </div>
    </footer>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>