<?php $__env->startSection('content'); ?>
<div id="page-head">
    <div id="page-title">
        <h1 class="page-header text-overflow"></h1>
    </div>
</div>
<div id="page-content">
   <?php if(session('msg')): ?>
     <div class="panel-alert">
         <div class="alert alert-success" role="alert">
              <button class="close" type="button"data-dismiss="alert" aria-label="Close"><i class="pci-cross pci-circle"></i></button>
              <div class="media" style="margin: 0"><?php echo e(session('msg')); ?></div>
         </div>
     </div>
   <?php endif; ?>
    <div class="row">
        <div class="col-xs-12 col-md-6">
            <div class="panel">
                <div class="panel-heading">
                    <div class="panel-control">
                       <button data-target="#modal-categorias" data-toggle="modal" class="btn btn-primary">Nueva Categoria</button>
                    </div>
                    <h3 class="panel-title">Listado de Categorias</h3>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Imagen</th>
                                    <th>Categoria</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php if( sizeof($categorias) > 0 ): ?>
                                  <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <tr>
                                         <td><img class="" width="50" src="<?php echo e($cat->imagen); ?>" alt=""></td>
                                         <td><?php echo e($cat->nombre); ?></td>
                                         <td class="text-center">
                                             <button class="btn btn-sm btn-danger hidden">
                                                 <i class="demo-psi-remove icon-lg"></i>
                                             </button>
                                             <button class="btn btn-sm btn-primary" data-target="#modal-categorias" data-toggle="modal" data-id="<?php echo e($cat->id); ?>">
                                                 <i class="demo-pli-pen-5 icon-lg"></i>
                                             </button>
                                         </td>
                                     </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               <?php else: ?>
                                  <tr>
                                     <td colspan="3">No hay categorias registradas</td>
                                  </tr>
                               <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xs-12 col-md-6">
            <div class="panel">
                <div class="panel-heading">
                    <div class="panel-control">
                         <button id="demo-dt-addrow-btn" data-target="#modal-subcategorias" data-toggle="modal" class="btn btn-primary">
                             <i class="demo-pli-plus"></i> Nueva Subcategoria
                         </button>
                    </div>
                    <h3 class="panel-title">Listado de Subcategorias</h3>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Imagen</th>
                                    <th>Categoria</th>
                                    <th>Subcategoria</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php if( sizeof($subcategorias) > 0 ): ?>
                                 <?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><img width="50" src="<?php echo e(asset('storage/'. $sub->imagen)); ?>" alt=""></td>
                                        <td><?php echo e($sub->categoria->nombre); ?></td>
                                        <td><?php echo e($sub->nombre); ?></td>
                                        <td class="text-center">
                                            <button class="btn btn-sm btn-danger hidden">
                                                <i class="demo-psi-remove icon-lg"></i>
                                            </button>
                                            <button class="btn btn-sm btn-primary" data-id="<?php echo e($sub->id); ?>" data-target="#modal-subcategorias" data-toggle="modal">
                                                <i class="demo-pli-pen-5 icon-lg"></i>
                                            </button>
                                        </td>
                                    </tr>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php else: ?>
                                 <tr>
                                    <td colspan="3">No hay categorias registradas</td>
                                 </tr>
                              <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modal-categorias" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
               <form class="" action="/categorias" method="post" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="old-img" value="" id="old-img">
                   <!--Modal header-->
                   <div class="modal-header">
                       <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                       <h4 class="modal-title">Registro de Categorias</h4>
                   </div>
                   <!--Modal body-->
                   <div class="modal-body">
                         <div class="form-group">
                              <label class="control-label" for="name">Nombre de la categoria</label>
                              <input id="categoria" required name="categoria" type="text" class="form-control input-md" required>
                         </div>
                         <div class="form-group">
                            <label class="control-label" for="name">Seleccione imagen</label>
                            <span class="btn btn-primary btn-file">
			                          Browse... <input type="file" name="img">
					             </span>
                         </div>
                   </div>
                   <!--Modal footer-->
                   <div class="modal-footer">
                       <button data-dismiss="modal" class="btn btn-default" type="button">Cerrar</button>
                       <button class="btn btn-primary" type="submit">Guardar</button>
                   </div>
                </form>
            </div>
        </div>
    </div>


<div class="modal fade" id="modal-subcategorias" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal" aria-hidden="true">
     <div class="modal-dialog">
         <div class="modal-content">
            <form class="" action="/subcategorias" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>
               <input type="hidden" name="old-img-sub" value="" id="old-img-sub">
                <!--Modal header-->
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><i class="pci-cross pci-circle"></i></button>
                    <h4 class="modal-title">Modal Heading</h4>
                </div>
                <!--Modal body-->
                <div class="modal-body">
                    <div class="form-group">
                        <label class="control-label" for="categoria">Categorias</label>
                        <div class="select">
                            <select name="categoria" id="categoria" required>
                                   <option disabled selected>Seleccione</option>
                                   <option value="1">sin categoria</option>
                                   <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->nombre); ?></option>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>
                        </div>
                    </div>
                    <div class="form-group">
                           <label class="control-label" for="subcategoria">Nombre de la subcategoria</label>
                           <input id="subcategoria" name="subcategoria" type="text" class="form-control input-md" required>
                    </div>
                    <div class="form-group">
                         <label class="control-label" for="img-subcat">Seleccione imagen</label>
                         <span class="btn btn-primary btn-file">
    	                          Browse... <input type="file" name="img-subcat">
    			            </span>
                    </div>
                </div>
                <!--Modal footer-->
                <div class="modal-footer">
                    <button data-dismiss="modal" class="btn btn-default" type="button">Cerrar</button>
                    <button class="btn btn-primary" type="submit">Guardar</button>
                </div>
             </form>
         </div>
     </div>
 </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>