<?php $__env->startSection('content'); ?>
<div id="page-content">
    <div class="row pad-btm">
       <div class="col-sm-6 toolbar-right"></div>
       <div class="col-sm-6 toolbar-right text-right">
           <a href="/promociones/editar/0" id="demo-btn-addrow" class="btn btn-success btn-lg">Nueva Promoción</a>
       </div>
    </div>
    <div class="panel">
        <div class="panel-body">
            <table class="table table-hover table-vcenter">
                <thead>
                    <tr>
                        <th class="min-width">Imagen</th>
                        <th>Promoción</th>
                        <th class="text-center min-width">Descuento</th>
                        <th class="min-width"></th>
                    </tr>
                </thead>
                <tbody>
                   <?php if(sizeof($promos) > 0 ): ?>
                      <?php $__currentLoopData = $promos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td class="text-center">
                                  <img width="50" src="<?php echo e(asset('storage/'. $pro->imagen)); ?>" alt="">
                              </td>
                              <td>
                                  <span class="text-main"><?php echo e($pro->nombre); ?></span>
                                  <br>
                                  <small class="text-muted"><?php echo e($pro->fecha_inicio . ' - ' . $pro->fecha_fin); ?></small>
                              </td>
                              <td class="text-center"><span class="text-danger text-semibold"><?php echo e($pro->descuento); ?>%</span></td>
                              <td class="text-center">
                                  <div class="btn-group dropdown">
                                      <button class="btn btn-trans dropdown-toggle dropdown-toggle-icon"
                                          data-toggle="dropdown" type="button" aria-expanded="false">
                                          <i class="demo-psi-dot-horizontal icon-lg"></i>
                                      </button>
                                      <ul class="dropdown-menu dropdown-menu-right" style="">
                                          <li><a href="#">Eliminar</a></li>
                                          <li><a href="/promociones/editar/<?php echo e($pro->codigo); ?>">Ver detalles</a></li>
                                          <li><a href="#">Ver productos</a></li>
                                      </ul>
                                  </div>
                              </td>
                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php else: ?>
                      <tr>
                         <td colspan="4" class="text-center">No se cargo ninguna promocion</td>
                      </tr>
                   <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>