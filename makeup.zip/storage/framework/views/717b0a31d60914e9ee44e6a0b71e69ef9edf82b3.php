<?php $__env->startSection('content'); ?>
<div id="page-content">
   <div class="row">
      <div class="col-md-8 table-responsive">
         <div class="panel">
            <div class="panel-body">
               <h3 class="text-main text-normal text-2x mar-no">Informacion de Orden</h3>
               <h5 class="text-uppercase text-muted text-normal" id="numOrden" data-orden="<?php echo e($pedido->id); ?>">Numero de Orden: <?php echo e($pedido->num_orden); ?></h5>
               <hr class="new-section-xs">
               <div class="row mar-top">
                    <div class="col-sm-4">
                        <div class="text-lg">
                           <p class="text-5x text-thin text-main text-center"><i class="demo-pli-calendar-4"></i></p>
                        </div>
                        <p class="text-2x text-bold text-center"><?php echo e(date('d M, Y', strtotime($pedido->fecha_pedido))); ?></p>
                        <p class="text-sm text-center">Fecha de Pedido</p>
                    </div>
                    <div class="col-sm-8">
                        <div class="list-group bg-trans mar-no">
                            <a class="list-group-item" href="/users/<?php echo e($pedido->cliente->id); ?>">
                               <i class="demo-pli-male icon-lg icon-fw"></i> <?php echo e($pedido->cliente->name); ?>

                            </a>
                            <a class="list-group-item" href="mailto:<?php echo e($pedido->cliente->email); ?>">
                               <i class="demo-pli-mail icon-lg icon-fw"></i> <?php echo e($pedido->cliente->email); ?>

                            </a>
                        </div>
                    </div>
                </div>
                <div class="text-right demo-nifty-btn-group">
                   <div class="btn-group">
                      <div class="dropdown">
                          <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown" type="button" aria-expanded="false">
                              Cambiar Estado <i class="dropdown-caret"></i>
                          </button>
                          <ul id="changeEstate" class="dropdown-menu dropdown-menu-right" style="">
                              <li><a href="#">Pagado</a></li>
                              <li><a href="#">Cancelado</a></li>
                          </ul>
                      </div>
                   </div>
                </div>
            </div>
         </div>
         <div class="panel">
             <table class="table invoice-summary" style="border-collapse: separate">
                 <thead>
                     <tr>
                         <th class="text-uppercase" style="padding-left: 20px" colspan="2">Productos</th>
                         <th class="min-col text-center text-uppercase">Cant.</th>
                         <th class="min-col text-center text-uppercase">Precio</th>
                         <th class="min-col text-right text-uppercase" style="padding-right: 20px">Total</th>
                     </tr>
                 </thead>
                 <tbody>
                    <?php
                       $total = 0;
                    ?>
                    <?php if( sizeof($pedido->productos) > 0 ): ?>
                       <?php $__currentLoopData = $pedido->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php
                              $importe = $prod->pivot->cantidad * $prod->precio_normal;
                              $total += $importe;
                          ?>
                           <tr>
                               <td width="80" style="padding-left: 20px">
                                  <img src="<?php echo e(asset('storage/'.$prod->imagenes[0]->url)); ?>" alt="Imagen de Producto" class="img-md">
                               </td>
                               <td>
                                  <a class="text-info" href="/productos/editar/<?php echo e($prod->codigo); ?>"><?php echo e($prod->nombre); ?></a>
                               </td>
                               <td class="text-center"><?php echo e($prod->pivot->cantidad); ?></td>
                               <td class="text-center">$ <?php echo e(number_format($prod->precio_normal, 0)); ?></td>
                               <td class="text-right" style="padding-right: 20px">$ <?php echo e(number_format($importe, 0)); ?></td>
                           </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php else: ?>
                        <tr>
                           <td colspan="5" class="text-center">No hay productos cargados</td>
                        </tr>
                     <?php endif; ?>
                 </tbody>
             </table>
             <div class="clearfix">
   	            <table class="table invoice-total">
   	                <tbody>
   	                    <tr>
   	                        <td class="text-2x text-main">Total</td>
   	                        <td class="text-2x text-main" style="padding-right: 20px">$ <?php echo e(number_format($total, 0)); ?></td>
   	                    </tr>
   	                </tbody>
   	            </table>
   	        </div>
         </div>
      </div>
      <div class="col-md-4">
         <div id="panelEstado" class="panel media pad-all <?php echo e($pedido->estadoPago->clase_css); ?>">
             <div class="media-left">
                 <span class="icon-wra icon-wap-sm bg-ifo">
                    <i class="<?php echo e($pedido->estadoPago->icono); ?> icon-3x"></i>
                 </span>
             </div>
             <div class="media-body">
                 <p class="mar-no">Estado de Orden</p>
                 <p id="nombreEstado" class="text-2x mar-no text-semibold"><?php echo e($pedido->estadoPago->estado); ?></p>
             </div>
         </div>
          <div class="panel">
             <div class="widget-header bg-purple">
               <img class="widget-bg img-responsive" src="<?php echo e(asset('image/map.jpg')); ?>" alt="Image">
            </div>
            <div class="panel-heading">
                <div class="panel-control">
                    <button class="btn btn-default" data-panel="fullscreen">
                        <i class="icon-max demo-psi-maximize-3"></i>
                        <i class="icon-min demo-psi-minimize-3"></i>
                    </button>
                </div>
                <h3 class="panel-title">Direccion de Envio</h3>
            </div>
            <div class="panel-body">
                <div class="mar-btm">
                    <p class="text-main text-lg mar-no">Nombre</p>
                    <?php echo e($pedido->cliente->name); ?>

                </div>
                <div class="mar-btm">
                    <p class="text-main text-lg mar-no">Direccion</p>
                    <?php echo e($pedido->cliente->datos_envio->direccion); ?>

                </div>
                <div class="mar-btm">
                    <p class="text-main text-lg mar-no">Correo</p>
                    <?php echo e($pedido->cliente->email); ?>

                </div>
                <div class="mar-btm">
                    <p class="text-main text-lg mar-no">Telefono</p>
                    <?php echo e($pedido->cliente->datos_envio->telefono); ?>

                </div>
            </div>
        </div>
        <div class="panel media middle pad-all">
             <div class="media-left">
                 <span class="icon-wrap icon-wrap-sm icon-circle bg-success">
                    <i class="demo-pli-wallet-2 icon-2x"></i>
                 </span>
             </div>
             <div class="media-body">
                <p class="text-muted mar-no">Metodo de Pago</p>
                 <p class="text-2x mar-no text-semibold text-main">PayU</p>
             </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>