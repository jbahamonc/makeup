<?php $__env->startSection('content'); ?>
    
    <div id="page-content">
        <div class="row pad-btm">
            <div class="col-sm-6 toolbar-right"></div>
            <div class="col-sm-6 toolbar-right text-right">
                <a href="/productos/editar/0" id="demo-btn-addrow" class="btn btn-success btn-lg">Nuevo Producto</a>
            </div>
        </div>
        <div class="row">
           <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if($pro->codigo != 'euDYCJQMId'): ?>
               <div class="col-xs-12 col-sm-6 col-md-3">
                   <div class="panel pos-rel">
                       <div class="pad-all text-center">
                           <a href="#">
                               <img alt="<?php echo e($pro->nombre); ?>" class="img-lg img-circle mar-ver" src="<?php echo e((count($pro->imagenes) > 0)? asset('storage/' . $pro->imagenes[0]->url) : asset('image/img-placeholder.jpg')); ?>">
                               <p class="text-lg text-semibold text-main"><?php echo e($pro->nombre); ?></p>
                               <p class="text-sm text-left">Ref <span class="pull-right"><?php echo e($pro->referencia); ?></span></p>
                               <p class="text-sm text-left">En almacen <span class="pull-right"><?php echo e($pro->cantidad); ?> UND</span></p>
                               <p class="text-normal text-dark text-bold">Precio: $<?php echo e(number_format($pro->precio_normal, 0)); ?></p>
                           </a>
                           <div class="text-center pad-to">
                               <div class="btn-group">
                                   <a href="" class="btn btn-sm btn-default"><i class="demo-pli-consulting icon-lg icon-fw"></i> Eliminar</a>
                                   <a href="/productos/editar/<?php echo e($pro->codigo); ?>" class="btn btn-sm btn-default"><i class="demo-pli-pen-5 icon-lg icon-fw"></i> Editar</a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>